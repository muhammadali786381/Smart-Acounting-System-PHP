   <div class="row">
          <div class="col-12 col-sm-6 col-md-3">
              <a href="<?php echo BASE_URL.ADMIN_DIR."/cash-book";?>"> 
            <div class="info-box">
              <span class="info-box-icon bg-info elevation-1"><i class="fas fa-cash-register"></i></span>
               <div class="info-box-content">
                <span class="info-box-text">Cash Book</span>
                <span class="info-box-number"><?php echo "";?></span>
              </div>
        <!-- /.info-box-content -->
            </div>
                  </a>
            <!--  /.info-box -->
          </div>
            <!-- /.col -->
          <div class="col-12 col-sm-6 col-md-3">
              <a href="<?php echo BASE_URL.ADMIN_DIR."/sale-purchase";?>"> 
            <div class="info-box mb-3">
              <span class="info-box-icon bg-danger elevation-1"><i class="fas fa-book-open"></i></span>

              <div class="info-box-content">
                <span class="info-box-text">Sale Purchase</span>
                <span class="info-box-number"><?php echo "";?></span>
              </div>
    <!-- /.info-box-content -->
            </div>
                </a>
    <!--/.info-box -->
          </div>
    <!-- /.col -->
    
        <div class="col-12 col-sm-6 col-md-3">
              <a href="<?php echo BASE_URL.ADMIN_DIR."/ledger";?>"> 
            <div class="info-box mb-3">
              <span class="info-box-icon bg-success elevation-1"><i class="fas fa-clipboard"></i></span>

              <div class="info-box-content">
                <span class="info-box-text">Ledger</span>
                <span class="info-box-number"><?php echo "";?></span>
              </div>
    <!-- /.info-box-content -->
            </div>
                </a>
    <!--/.info-box -->
          </div>
    <!-- /.col -->
    
    <div class="col-12 col-sm-6 col-md-3">
              <a href="<?php echo BASE_URL.ADMIN_DIR."/head-list";?>"> 
            <div class="info-box mb-3">
              <span class="info-box-icon bg-warning elevation-1"><i class="fas fa-users"></i></span>

              <div class="info-box-content">
                <span class="info-box-text">New Account</span>
                <span class="info-box-number"><?php echo "";?></span>
              </div>
    <!-- /.info-box-content -->
            </div>
                </a>
    <!--/.info-box -->
          </div>
    <!-- /.col -->
    
    <!--fix for small devices only -->
          <div class="clearfix hidden-md-up"></div>

        </div>
   <!--/.row -->