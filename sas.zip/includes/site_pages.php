<?php

/* 
 * All pages list that is view by users
 * If you Add more pages into site then also update this file
 * 
 * Current not working in features update we are working on it.
 */

$page=array();

$page['login']='login';
$page['signup']='signup';
$page['dashboard']='dashboard';
