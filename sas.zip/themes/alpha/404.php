<section class="sec-padding">
    <div class="container">
      <div class="row">
      
	<div class="error_holder">
        <h1 class="uppercase title text-orange-2">404</h1>
        <br/>
        <h2 class="uppercase"><?php echo $lang['404_tagline'];?></h2>
        <p><?php echo $lang['404_shortmsg'];?></p>
        </div>
      
      </div>
    </div>
  </section>
  <!--end item -->
  <div class="clearfix"></div>